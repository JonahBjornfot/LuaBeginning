
-- Global Variabels

local Variabels = require("Engine/Variabels")
Variabels()

-- Sounds!

local Sounds = require("Engine/sounds")
Sounds()

-- Draws on screen

local Draw  = require("Engine/draw")
Draw()

-- Functions, the code that makes the game work.

local keypress = require("Engine/keypressed")
keypress()

-- Debug console

love.load = function ()
    print("The game has started!")
    mybackground = love.graphics.newImage('Other/pictu.jpg')
end
