function love.conf(t)
    t.window.width = 1366
    t.window.height = 768
end