return function ()
    love.keypressed = function(pressed_key)
        if pressed_key == '1' then
          if RandomNumber == 1 then
            score = score + 1
            current_color = {love.math.random(0, 1), love.math.random(0, 1), love.math.random(0, 1), 1}
            RandomNumber = love.math.random(1, 4)
            gamenumber = RandomNumber
          else 
            score = score - 1
            Sound3:play()
          end
        elseif pressed_key == '2' then
          if RandomNumber == 2 then
            score = score + 1
            current_color = {love.math.random(0, 1), love.math.random(0, 1), love.math.random(0, 1), 1}
            RandomNumber = love.math.random(1, 4)
            gamenumber = RandomNumber
          else 
            score = score - 1
            Sound3:play()
          end
        elseif pressed_key == '3' then
          if RandomNumber == 3 then
            score = score + 1
            current_color = {love.math.random(0, 1), love.math.random(0, 1), love.math.random(0, 1), 1}
            RandomNumber = love.math.random(1, 4)
            gamenumber = RandomNumber
          else 
            score = score - 1
            Sound3:play()
          end
        elseif pressed_key == '4' then
          if RandomNumber == 4 then
            score = score + 1
            current_color = {love.math.random(0, 1), love.math.random(0, 1), love.math.random(0, 1), 1}
            RandomNumber = love.math.random(1, 4)
            gamenumber = RandomNumber
          else 
            score = score - 1
            Sound3:play()
          end
        elseif pressed_key == 'escape' then
          love.event.quit()
        elseif pressed_key == 'space' then
          score = 0
          seconds = 30
          RandomNumber = love.math.random(1, 4)
          gamenumber = RandomNumber
          gamename = "Restarted"
          Sound5:play()
          Sound2:play()
          Sound1:stop()
          Sound4:stop()
        elseif pressed_key == "s" then
            RandomNumber = love.math.random(1, 4)
            gamenumber = RandomNumber
            gamename = "Running"
            Sound5:play()
            Sound2:play()
            end
            love.update = function (dt)
              seconds = seconds - dt
              if seconds < 0 then
                seconds = seconds + dt
                RandomNumber = 0
                gamenumber = RandomNumber
                gamename = "Ended"
                Sound2:stop()
                if score > highscore then
                   highscore = score
                  Sound1:play()
                elseif score < highscore then
                  Sound4:play()
                end
            end
          if pressed_key == "p" then
            score = score - 5
            gamenumber = 0
            gamename = "Paused, S to Resume"
            Sound2:stop()
            Sound6:play()
            love.update = function()
              seconds = seconds
            end
          end
        end
      end
end