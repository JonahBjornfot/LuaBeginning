return function ()
Sound1 = love.audio.newSource("Audio/johnsen.wav", "static")
Sound2 = love.audio.newSource("Audio/sky.wav", "static")
Sound3 = love.audio.newSource("Audio/wrong.wav", "static")
Sound4 = love.audio.newSource("Audio/whymad.wav", "static")
Sound5 = love.audio.newSource("Audio/letsgo.wav", "static")
Sound6 = love.audio.newSource("Audio/winxp.wav", "static")
end