return function ()
    current_color = {love.math.random(0, 1), love.math.random(0, 1), love.math.random(0, 1), 1}
    txtfont = love.graphics.newFont('Other/tfont.ttf', 35)
    gamename = "SpamKlickers"
    seconds = 30
    score = 0
    gamenumber = 0
    highscore = 0
    red = 100/255
    green = 100/255
    blue = 100/255
    Color = {red, green, blue}
    square = {100, 100, 100, 300, 1275, 300, 1275, 100}
    mybackground = nil
end